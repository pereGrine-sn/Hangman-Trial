import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    System.out.println("Thanks for starting Hangman, the goal is to guess the chosen word in 5 guesses or less!");
    Scanner reaDER = new Scanner(System.in);
    String guessWord = randomWord();
    String hiddenWord = "";
    
  
    for (int f = 0; f < guessWord.length(); f++)
    {
      hiddenWord += "*"; // Adds in the astericks to the guessed word
    }
    int remGuesses = 5;
    String letterGuessed = "";
    Boolean win = false;
    
     while (remGuesses > 0);
    {
      System.out.println("Here's what you have to guess: " + hiddenWord);
      System.out.println("You have " + remGuesses + "left");
      System.out.println("What do you want to try?");
      String playerAns = reaDER.nextLine(); // Starts the scanner for guessing letters
      Boolean alrGuessed = false;
      
      
       for(int i = 0; i < letterGuessed.length(); i++){
        if(letterGuessed.substring(i, i + 1).equals(playerAns)){
          alrGuessed = true;
        }
        }
    
       if (alrGuessed){
        System.out.println("You've already guessed that letter!"); 
       }
      else {
      letterGuessed += playerAns + " ";
      boolean correct = false; 
        for (int i = 0; i < guessWord.length(); i++){
          if (guessWord.substring(i, i + 1).equals(playerAns)){
            correct = true;
          }
        }
        
        if (correct){
          System.out.println("Good Job!");
          String volu = "";
          for (int i = 0; i < guessWord.length(); i++){
            if (guessWord.substring(i, i + 1).equals(playerAns)){
              volu += guessWord.substring(i, i + 1);
            }
            else if (!hiddenWord.equals("*")){
              volu += hiddenWord.substring(i, i + 1);
            }
            else {
               hiddenWord += "*";
            }
          }
              hiddenWord = volu;
           }  
         }
        else {
          System.out.println("Too bad....");
          remGuesses--;
        }
      }
    win = true;
    for(int i = 0; i < hiddenWord.length(); i++) {
      if (hiddenWord.substring(i, i + 1).equals("*")){
        win = false;
      }
    }
      if (win){
        remGuesses = 0; //leaves while loop
      }
    }

      if (win){
        System.out.println("YOU DID IT!!");  
      }
      else {
        System.out.println("You failed.");
      }
    System.out.println("The mystery word was" + guessWord);
    System.out.println("Thanks again for playing!");
  
  

public static String randomWord() // Sets up a random word to be generated
  {
  int rng = (int)(Math.random()*6);
  if(rng == 1) {
    return "COMPUTER";
  }
  else if(rng == 2) {
    return "MIDNIGHT";
  }
  else if(rng == 3){
    return "FAILURES";
    
    }
  else if(rng == 4){
    return "ABSOLUTE";
  }
    return "PROGRAMS";
  }
}

